# from distutils.core import setup
from setuptools import setup, find_packages 
setup(name = 'production',version = '1.0',
      py_modules = ['production.production_whole'],
      author = 'lqkpython',
      author_email = 'luqikun@gagogroup.com',
      url = 'http://www.gagogroup.com',
      description = 'A simple calculation for grass production ',
      packages=find_packages(exclude=['*.*']))