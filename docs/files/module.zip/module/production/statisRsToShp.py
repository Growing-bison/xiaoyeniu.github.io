from rasterstats import zonal_stats
import csv
import sys
from shapely import wkt, geometry
from shapely.geometry import asShape
import geojson
import codecs
from area import area

# data = []
# stats = zonal_stats(sys.argv[1],sys.argv[2],stats="min max mean count sum ",nodata=99,categorical=True,category_map={"a":1,"b":2,"c":3,"d":4},geojson_out=True)
#
# for t in stats:
#
#     name = t.get('properties').get(sys.argv[3])
#
#     a = t.get('properties').get(1.0)
#
#     b = t.get('properties').get(2.0)
#
#     c = t.get('properties').get(3.0)
#
#     d = t.get('properties').get(4.0)
#
#     count = t.get('properties').get('count')
#
#     print(name, a, b, c, d, count)
#     data.append([name, a, b, c, d, count])
#
# with open(sys.argv[4],"w") as csvfile:
#     writer = csv.writer(csvfile,dialect='excel')
#     m = len(data)
#     for i in range(m):
#          writer.writerow(data[i])
# csvfile.close()

data = [['name','a','b','c','d','count']]
input_tif = r'I:\step4_8month_production\wlg\10_m\wlg_08_production_10m.tif'
# input_filelist = glob.glob(r'H:\ls_dacc\step6_yanzihua_class\output\tmp_10m')
input_shp = r'E:\luqikun\RW-170426_mengcao\datasource\edit\shp\from_mengcao_1024\wlg_jth_32650.geojson'

property_shp = 39
output_csv = r'K:\step6_yanzihua_class\ls\xwq_tuihua.csv'
# def shp_zonal_stats(input_tif, input_shp, property_shp):
    
stats = zonal_stats(input_shp, input_tif, stats="min max mean count sum ", nodata=-99999, categorical=True,
                category_map={"a": 11.0, "b": 12.0, "c": 49.0, "d": 50.0, "e":51.0, "f":52.0}, geojson_out=True, global_src_extent=False)
for t in stats:
    name = t.get('properties').get(property_shp)

    a = t.get('properties').get(11.0)

    b = t.get('properties').get(12.0)

    c = t.get('properties').get(49.0)

    d = t.get('properties').get(50.0)

    e = t.get('properties').get(51.0)

    f = t.get('properties').get(52.0)

    count = t.get('properties').get('count')

    print(name, a, b, c, d, e, f, count)
    data.append([name, a, b, c, d, e, f, count])
# shp_zonal_stats(input_tif, input_shp, property_shp)
# with open(output_csv, "w") as csvfile:
#     writer = csv.writer(csvfile, dialect='excel')
#     m = len(data)
#     for i in range(m):
#         writer.writerow(data[i])
# csvfile.close()
