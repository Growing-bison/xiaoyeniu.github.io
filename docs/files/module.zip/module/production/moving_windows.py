#!/usr/bin/env python3.5
# -*- coding: utf-8 -*-

import numpy as np
import os
from osgeo import gdal
import gdal
from gdalconst import *
import sys
import pandas as pd
from math import log
import datetime
import concurrent.futures
import glob
import wmi
import os
import platform
import time


def split_image_by_row_column_overlapping(file,row,column,out_path):

    if not os.path.exists(out_path):
        os.mkdir(out_path)

    dataset = gdal.Open(file, gdal.GA_ReadOnly)
    driver = dataset.GetDriver()

    print(cpu_mem())
    band = dataset.GetRasterBand(1)
    print(cpu_mem())
    width = dataset.RasterXSize
    height = dataset.RasterYSize
    xwin = int(width / column + 1)
    ywin = int(height / row + 1)

    geotransform = dataset.GetGeoTransform()
    prejectionref = dataset.GetProjectionRef()
    nodata_value = dataset.GetRasterBand(1).GetNoDataValue()
    print(nodata_value)
    # dataset.GetRasterBand(1).GetNoDataValue() # 获取nodata对应的值
    # xoffset = int((x - originX)/pixelWidth)
    # yoffset = int((y - originY)/pixelHeight)

    block_width = int(width / row + 1)  # block的x方向长度
    block_height = int(height / column + 1)  # block的y方向长度
    block_xsize = int(width / (block_width / 2) + 1)  # x方向有几个block
    block_ysize = int(height / (block_height / 2) + 1)  # y方向有几个block


    ### 图像读取方法：按照block（块读入，以按行读取顺序），避免占用内存过大

    for i in range(block_ysize - 1):# 因为总长1/2的block_height为2n，但真正读取的数量是2n-2
        for j in range(block_xsize - 1):
            print(i, j)
            ### 判断最后一列的block是否超出图像的边界范围，如果超出，则以从倒数1个block所在的图像位置直到图像结束位置作为最后1个block的长度和宽度
            x_len_num = j + 1 # x_len_num 最大即是2n-1，block_xsize -1
            y_len_num = i + 1

            if j == (block_xsize-2):
                block_width_input = int(width - (block_xsize-2) * block_width/2)
                xoffset = int((block_xsize-2) * (block_width / 2))
            else:
                block_width_input = block_width
                xoffset = (x_len_num - 1) * (block_width / 2)

            if i == (block_ysize-2):
                block_height_input = int(height - (block_ysize-2) * block_height/2)
                yoffset = int((block_ysize - 2) * (block_height / 2))
            else:
                block_height_input = block_height
                yoffset = (y_len_num - 1) * (block_height / 2)

            # print(xoffset+block_width_input, yoffset+block_height_input, xoffset, yoffset, block_width_input, block_height_input)
            small_block_data = band.ReadAsArray(xoffset, yoffset, block_width_input, block_height_input)
            small_block_data.astype(np.float)

            ot_out_file = os.path.join(out_path, "%d.%d.tiff" % (i + 1, j + 1))
            otDataset = driver.Create(ot_out_file, xsize=block_width_input, ysize=block_height_input, bands=1, eType=GDT_Float32)

            GT = geotransform
            small_tiff_originX, small_tiff_originY =Geo_Points(xoffset, yoffset, GT)
            small_tif_geotransform = [small_tiff_originX, 10, 0, small_tiff_originY, 0, -10] # (originX, pixelWidth, 0, originY, 0, pixelHeight)
            otDataset.SetGeoTransform(small_tif_geotransform)
            otDataset.SetProjection(prejectionref)
            otDataset.GetRasterBand(1).SetNoDataValue(nodata_value)

            outBand = otDataset.GetRasterBand(1)
            outBand.WriteArray(small_block_data, 0, 0)
            outBand.FlushCache()
            outBand = None
            otDataset = None
            del otDataset, outBand
