#!/usr/bin/env python3.5
# -*- coding: utf-8 -*-

import numpy as np
import os
from osgeo import gdal
# import gdal
from gdalconst import *
import sys
import pandas as pd
from math import log
from datetime import date
from datetime import time
from datetime import datetime
from datetime import timedelta
import time
import concurrent.futures
import glob
import shutil



def runTask(func, day=0, hour=0, min=2, second=0):
    '''该函数是对函数等实现延迟执行

    :param func: 输入函数名称
    :param day: 天数，(0,无穷)
    :param hour: 小时数，[0,24]
    :param min: 分钟数，[0,60]
    :param second: 秒数，[0，60]
    :return: none
    '''
    now = datetime.now()      # get current time
    strnow = now.strftime('%Y-%m-%d %H:%M:%S')
    print ("now:",strnow)
    period = timedelta(days=day, hours=hour, minutes=min, seconds=second)      # get net_run time
    next_time = now + period
    strnext_time = next_time.strftime('%Y-%m-%d %H:%M:%S')
    print ("next run:", strnext_time)
    while True:
      now = datetime.now()
      strnow = now.strftime('%Y-%m-%d %H:%M:%S')
      # if system time eq next_time run the specific task(hello func)
      if str(strnow) == str(strnext_time):
          print (strnow)
          func()
          print ("Task done.")
          break

def creat_project_subfile(file_list:list):
    '''该函数用于在当前目录之下创建文件夹

    :param file_list: 列表元素
    :return: none
    '''
    project_dir = os.getcwd()
    for name in file_list:
        path = os.path.join(project_dir, name)
        isExists = os.path.exists(path)
        if not isExists:
            print(path + '创建成功')
            os.makedirs(path)
        else:
            print(path + '目录已存在')

def read_plot_tif_fun(input_filename):
    '''该函数用于读入tif文件为dataframe

    :param input_filename: 需要读入的tif文件（带路径）
    :return: tif读入成numpy的多维数组，变量名称为'pix'的dataframe，变量名称为'pix'的dataframe仅采取部分样点的dataframe
    '''
    test1 = gdal.Open(input_filename, GA_ReadOnly)
    test1band = test1.GetRasterBand(1)
    test1Data = test1band.ReadAsArray()  # 成为python的numpy的arrary数组形式
    df = pd.DataFrame(test1Data.flatten()).dropna()  # 将多维数组转变为一维数组，将数组转换为dataframe，pd.DataFrame()
    df.columns = ['pix']  # # 重新命名变量名，以'pix'
    df_sample = df.sample(int(len(df) / int(1000)))  # 数据量过大，对源数据进行采样
    return test1Data, df, df_sample

def adjust_zj_fun(input_filename):
    '''该函数对影像数据进行重分类或函数计算

    :param input_filename: 需要读入的tif文件（带路径）
    :param class_pix: 用于分类的特征值所构成的list
    :return: dataframe数据结构，完成重分类之后的结果
    '''
    test1 = gdal.Open(input_filename, gdal.GA_ReadOnly)
    if test1 is None:
        print('cannot open: ', os.path.basename(input_filename))
        sys.exit(1)
    test1band = test1.GetRasterBand(1)
    test1Data = test1band.ReadAsArray()
    test1band = None  # 删除testband，避免占内存

    # 根据具体，调整数值
    df_use_for_class = pd.DataFrame(test1Data.astype(float), dtype='float32')
    df_use_for_class[(df_use_for_class >float(40)) & (df_use_for_class <= float(49.5))] = float(49)
    df_use_for_class[(df_use_for_class >float(49.5)) & (df_use_for_class <= float(50.5))] = float(50)
    df_use_for_class[(df_use_for_class >float(50.5)) & (df_use_for_class <= float(51.5))] = float(51)
    df_use_for_class[(df_use_for_class >float(51.5)) & (df_use_for_class <= float(52.9))] = float(52)

    #感兴趣区域，进行计算
    df_use_for_class[(df_use_for_class < float(1)) & (df_use_for_class > float(0))] = df_use_for_class[
        (df_use_for_class < float(1)) & (df_use_for_class > float(0))].applymap(lambda ndvi_value:log(ndvi_value)
                                                                                                  *254.5*4+405.8*4)
    time.sleep(2)
    return df_use_for_class

def export_to_tif_fun(input_filename, class_final_df, otNDVI_class_filename):
    '''该函数是根据源影像，将完成计算之后的dataframe，输出成tif

    :param input_filename: 需要读入的tif文件（带路径）
    :param class_final_df: dataframe数据
    :param source_filename: 输出的影像路径及名称，’×××.tif‘
    :return:
    '''
    input_tif = gdal.Open(input_filename, GA_ReadOnly)
    driver = input_tif.GetDriver()
    rXSize = input_tif.RasterXSize
    rYSize = input_tif.RasterYSize
    input_tifGeotrans = input_tif.GetGeoTransform()
    input_tifProj = input_tif.GetProjectionRef()
    input_tifband = input_tif.GetRasterBand(1)
    input_tifData = input_tifband.ReadAsArray()
    nodata = input_tif.GetRasterBand(1).GetNoDataValue()
    input_tifband = None  # 清空所占内存
    del input_tifband

    otDataset = driver.Create(otNDVI_class_filename, rXSize, rYSize, 1, GDT_Float32)
    otDataset.SetGeoTransform(input_tifGeotrans)
    otDataset.SetProjection(input_tifProj)

    outBand = otDataset.GetRasterBand(1)
    outBand.WriteArray(np.array(class_final_df), 0, 0)
    outBand.FlushCache()
    outBand.SetNoDataValue(nodata)
    outBand = None  # 清空所占内存
    del outBand

def combine_input_output(input_filename, otNDVI_class_filename):
    '''该函数用于剔除超出正常范围的异常值

    :param input_filename: 输入的影像数据
    :param otNDVI_class_filename: 输出的影像数据
    :return: none
    '''
    min_value = float(50)*4 # wlg-50,chenqi-50
    max_value = float(405.8)*4 # wlg-326.38,chenqi-221.96
    df_use_for_class = adjust_zj_fun(input_filename)
    df_use_for_class = check_production_value(min_value, max_value, df_use_for_class)
    export_to_tif_fun(input_filename, df_use_for_class, otNDVI_class_filename)

def check_production_value(min_value, max_value, df_use_for_class):
    '''该函数用于检查数据，并将超出范围的数据置为指定数值（如nodata是-99999时）

    :param min_value: float,最小值
    :param max_value: float,最大值
    :param df_use_for_class: dataframe,待检查的数据
    :return: dataframe,新的dataframe
    '''
    # 超出ndvi=1的部分，设置为nodata
    # 小于ndvi=0.2的部分，设置为nodata
    # ndvi 小于0的部分，设置为nodata
    df_use_for_class[(df_use_for_class > float(max_value))] = -99999
    df_use_for_class[
        (df_use_for_class < float(min_value)) & (df_use_for_class > float(52))] = -99999
    df_use_for_class[(df_use_for_class < float(49))] = -99999

    return df_use_for_class


def split_image_by_row_column(file, row, column, out_path):
    '''该函数是根据行列切分影像数据

    :param file: tif,影像数据
    :param row: int,行数
    :param column: int,列数
    :param out_path: document_name,输出到某个文件夹路径及名称
    :return: none
    '''

    if not os.path.exists(out_path):
        os.mkdir(out_path)
    dataset = gdal.Open(file, gdal.GA_ReadOnly)
    width = dataset.RasterXSize
    height = dataset.RasterYSize
    xwin = int(width / column + 1)
    ywin = int(height / row + 1)
    cmdtmp = "gdal_translate -srcwin {xorg} {yorg} {xwin} {ywin} {filepath} {outfile}"
    for i in range(row):
        for j in range(column):
            xorg = max(j * xwin - 1, 0)
            yorg = max(i * ywin - 1, 0)
            out_file = os.path.join(out_path, "%d.%d.tif" % (i + 1, j + 1))
            cmd = cmdtmp.format(xorg=xorg, yorg=yorg, xwin=xwin, ywin=ywin, filepath=file, outfile=out_file)
            try:
                os.system(cmd)
            except Exception as err:
                raise Exception(err)

def muti_process(source_file_path, output_filename, processpoolexecutor_num, for_cal_function):
    '''该函数在多核cpu上实现函数的多进程运算，提升运算效率

    :param source_file_path: 所需进行计算的tif文件所文件夹的路径
    :param output_filename: tif计算结果的输出路径
    :param processpoolexecutor_num: 进程数量，如2、4
    :for_cal_function: 欲进行计算采用的函数
    :return:
    '''

    data_source_path = os.path.join(source_file_path, '*.tif*')
    output_calfiles_dir = output_filename
    temp_path = os.listdir(source_file_path)
    source_dir_filename = [f for f in temp_path if not f.startswith('.')]
    with concurrent.futures.ProcessPoolExecutor(processpoolexecutor_num) as executor:
        image_files = glob.glob(data_source_path)
        output_filenames = []
        for i, value in enumerate(source_dir_filename):
            output_calfiles_filename = os.path.join(output_calfiles_dir, source_dir_filename[i])
            output_filenames.append(output_calfiles_filename)

        j = 0
        for image_file, output_namefilename in zip(image_files,
                                                   executor.map(for_cal_function, image_files, output_filenames)):
            j = j + 1
            print("calculate %s" % (j))

        print('---'*20, '\n', 'Multiprocess calculate over!!', '---'*20, '\n', 'next step: delete unuseful image')

def muti_tif_merge_one(list_temp_name, tif_input_dir_path, output_dir_path, output_vrtfile, output_tiffile):
    # 写入文件名称，作为buildvrt的list.txt###
    txt_path = os.path.join(output_dir_path, list_temp_name)
    f = open(txt_path, 'w')
    start = datetime.now()
    for line in glob.glob(os.path.join(tif_input_dir_path, '*.tif*')):
        f.writelines(line)
        f.write('\n')
    f.close()

    vrt_filename = os.path.join(output_dir_path, output_vrtfile)
    mergetif_filename = os.path.join(output_dir_path, output_tiffile)
    os.system('gdalbuildvrt -input_file_list %s %s ' % (txt_path, vrt_filename))
    os.system('gdal_translate %s %s ' % (vrt_filename, mergetif_filename))
    end = datetime.now()
    print("Merging images spend time: ", end - start)

def main():
    project_dir = os.getcwd()
    file_list = ['Clip_file', 'Calover_file', 'Merge']
    creat_project_subfile(file_list)
    prepare_for_clip_filename = r"I:\step4_8month\wlg\wlg0724_to_0819_nodata.tif"
    split_output_dir = os.path.join(project_dir, file_list[0])

    start = datetime.now()
    split_image_by_row_column(prepare_for_clip_filename, 5, 5, '%s/' % (split_output_dir))
    end = datetime.now()
    print("Splitting image spend time: ", end - start)

    # 计算
    tif_source_path = split_output_dir
    tif_output_path = os.path.join(project_dir, file_list[1])
    processpoolexecutor_num = 4
    muti_process(tif_source_path, tif_output_path, processpoolexecutor_num, combine_input_output)

    # delete split_output tif_files
    # shutil.rmtree(tif_output_path)
    # print('---'*20, '\n', 'Finish split_output_dir_deleting!','\n','Next step: merge dispersive image into one image')

    # 将多tif合成一个tif
    list_temp_name = 'list.txt'
    output_dir_path = os.path.join(project_dir, file_list[2])
    tif_input_dir_path = os.path.join(project_dir, file_list[1])
    output_vrtfile = 'Merge2.vrt'
    output_tiffile = 'Merge2.tif'
    muti_tif_merge_one(list_temp_name, tif_input_dir_path, output_dir_path, output_vrtfile, output_tiffile)

    # delete split_output tif_files
    shutil.rmtree(tif_output_path)
    print('---'*20, '\n', 'Finish calculated_tif deleting!','\n','Next step: merge dispersive image into one image')



if __name__ == "__main__":
    main()
